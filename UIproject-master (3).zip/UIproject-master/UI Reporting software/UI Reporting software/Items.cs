﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI_Reporting_software
{
    public class Items
    {
            public string Item_name { get; set; }
            public int Unit_amount { get; set; }
            public int Unit_price { get; set; }
            public int Total { get; set; }
    }
}
