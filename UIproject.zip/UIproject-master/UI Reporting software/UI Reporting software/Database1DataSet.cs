﻿namespace UI_Reporting_software
{


    partial class Database1DataSet
    {
        partial class DataTable1DataTable
        {
        }
    }
}
